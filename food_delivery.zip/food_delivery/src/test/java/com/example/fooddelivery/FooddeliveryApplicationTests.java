package com.example.fooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FooddeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
