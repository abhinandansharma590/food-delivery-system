package com.example.fooddelivery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.fooddelivery.model.Order;
import com.example.fooddelivery.repository.OrderRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository repo;

    public Order placeOrder(Order order) {
        order.setStatus("CREATED");
        return repo.save(order);
    }

    public Order assignDelivery(Long id) {
        Order order = repo.findById(id).orElseThrow();
        order.setDeliveryAgent("Agent1");
        order.setStatus("OUT_FOR_DELIVERY");
        return repo.save(order);
    }

    public Order getOrder(Long id) {
        return repo.findById(id).orElseThrow();
    }
}