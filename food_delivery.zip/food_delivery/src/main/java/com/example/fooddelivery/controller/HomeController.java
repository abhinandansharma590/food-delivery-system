package com.example.fooddelivery.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController implements ErrorController {

    @GetMapping("/")
    public String home() {
        return "forward:/index.html";
    }

    @RequestMapping("/error")
    public String error() {
        return "forward:/index.html";
    }
}
