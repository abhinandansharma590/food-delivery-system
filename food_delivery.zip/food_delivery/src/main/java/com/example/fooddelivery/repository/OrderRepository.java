package com.example.fooddelivery.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.fooddelivery.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
}